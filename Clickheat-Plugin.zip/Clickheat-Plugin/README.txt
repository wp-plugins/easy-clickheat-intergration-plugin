Thank you for downloading our plugin for the Clickheat tracking system

== Installation ==

Download and install the Clickheat system into a folder called "clickheat" in your root web folder. i.e. http://www.mydomain.com/clickheat

Then activate this plugin
1. Unzip and upload the clickheat.php file into your `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Test the system by adding the "?debugclickheat" debug code to the end of any page link on your site. i.e. http://www.site.com/index.html?debugclickheat


We are releasing this plugin under GPL2 

Plugin Name: Clickheat
Plugin URI: http://www.impressionengineers.com/wordpress/clickheat
Description: Clickheat tracking code integration for Wordpress by Impression Engineers.
Author: Impression Engineers
Author URI: http://www.impressionengineers.com/
Version: 1.0